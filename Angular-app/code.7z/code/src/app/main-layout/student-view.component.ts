import {Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from './student';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

@Component({
  selector: 'student-view',
  templateUrl: './student-view-component.html',
  styleUrls: ['./common.css']
})

@Injectable()
export class StudentViewComponent implements OnInit{
    title = 'app';
    students: Student[];

  ngOnInit() {
      this.retrieveStudents();
  }

  constructor(private httpClient: HttpClient ){ 
      
  }
  

  serverCall() : Observable<Student[]> {
      return this.httpClient.get<Student[]>("http://localhost:8080/student/getStudents");
  }

  retrieveStudents() : void{
      this.serverCall().subscribe(results => this.students = results);
  }

  submitStudent() : void{

  }
}

