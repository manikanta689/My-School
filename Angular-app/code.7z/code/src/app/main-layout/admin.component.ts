import {Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-root',
  templateUrl: './admin-component.html',
  styleUrls: []
})
export class AdminComponent implements OnInit{
  ngOnInit() {
  }
  title = 'app';
}

