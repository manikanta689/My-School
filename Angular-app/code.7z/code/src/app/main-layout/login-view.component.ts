import {Component, OnInit } from '@angular/core';

@Component({
  selector: 'login-view',
  templateUrl: './login-view-component.html',
  styleUrls: []
})
export class LoginViewComponent implements OnInit{
  ngOnInit() {
  }
  title = 'app';
}
