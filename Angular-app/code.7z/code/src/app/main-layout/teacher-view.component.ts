import {Component, OnInit } from '@angular/core';

@Component({
  selector: 'teacher-view',
  templateUrl: './teacher-view-component.html',
  styleUrls: []
})
export class TeacherViewComponent implements OnInit{
  ngOnInit() {
  }
  title = 'app';
}
