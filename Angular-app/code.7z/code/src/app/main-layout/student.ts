export class Student {
  rollNumber : string;
  sectionId : string;
  studentid : string;
  studentName : string;
  userId : string;
}