import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomePageComponent } from './main-layout/home-page.component';
import { TeacherViewComponent } from './main-layout/teacher-view.component';
import { AdminComponent } from './main-layout/admin.component';
import { StudentViewComponent } from './main-layout/student-view.component';
import { LoginViewComponent } from './main-layout/login-view.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    TeacherViewComponent,
    AdminComponent,
    StudentViewComponent,
    LoginViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
